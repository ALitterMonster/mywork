package com.forest.service.logging;

public class LoggingPlanService {

}
